package com.example.theescapegame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;

public class MainGame extends AppCompatActivity {
    Button Button1, Button2, Button3;
    MediaPlayer shock, victory, gas;

    public View RelativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_game);
        Button1 = (Button) findViewById(R.id.button1);
        Button2 = (Button) findViewById(R.id.button2);
        Button3 = (Button) findViewById(R.id.button3);
        shock = MediaPlayer.create(this, R.raw.shock);
        victory = MediaPlayer.create(this, R.raw.victory);
        gas = MediaPlayer.create(this, R.raw.gas);


        }
                public void toast (View v){
                    if (v.equals(Button1)) {
                        Toast.makeText(getApplicationContext(),
                                "You chose Door-1",
                                Toast.LENGTH_SHORT).show();
                        Intent goToActivity3_1 = new Intent();
                        goToActivity3_1.setClass(this, Activity3_1.class);
                        startActivity(goToActivity3_1);
                        shock.start();
                    }

                    if (v.equals(Button2)) {
                        Toast.makeText(getApplicationContext(),
                                "You chose Door-2",
                                Toast.LENGTH_SHORT).show();
                        Intent goToActivity3_2 = new Intent();
                        goToActivity3_2.setClass(this, Activity3_2.class);
                        startActivity(goToActivity3_2);
                        victory.start();
                    }

                    if (v.equals(Button3)) {
                        Toast.makeText(getApplicationContext(),
                                "You chose Door-3",
                                Toast.LENGTH_SHORT).show();
                        Intent goToActivity3_3 = new Intent();
                        goToActivity3_3.setClass(this, Activity3_3.class);
                        startActivity(goToActivity3_3);
                        gas.start();
                    }

                }

    };


